package com.optisol.helper;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optisol.domain.Metrics;
import com.optisol.domain.Project;
import com.optisol.domain.SubProject;
import com.optisol.messages.CommonMessage;
import com.optisol.messages.ResponseMessage;
import com.optisol.messages.ResponseStatus;
import com.optisol.messages.ResponseStatusCode;
import com.optisol.repository.MetricsRepository;
import com.optisol.repository.ProjectRepository;
import com.optisol.repository.SubProjectRepository;

@Service
public class ProjectServiceHelper {
   
	@Autowired
	private ProjectRepository projectRepository;
	
	@Autowired
	private MetricsRepository metricRepo;
	
	@Autowired
	private SubProjectRepository subProjectRepository;
	
	public ResponseMessage<Project> createProject(Project obj, HttpServletResponse response) {
		ResponseStatus status = null;  

		try {
			if (obj.getName() != null && !obj.getName().isEmpty() && obj.getTechnology() != null
					&& !obj.getTechnology().isEmpty()) {
				Metrics metric = obj.getMetrics();
				metric = metricRepo.save(metric);
				obj.setMetrics(metric);
				obj = projectRepository.save(obj);
				List<SubProject> subProject = obj.getSubReport();
				subProject = subProjectRepository.saveAll(subProject);
				response.setStatus(ResponseStatusCode.STATUS_CREATED);
				status = new ResponseStatus(ResponseStatusCode.STATUS_OK, CommonMessage.SUCCESS);
				return new ResponseMessage<>(status, obj);
			} else {
				response.setStatus(ResponseStatusCode.STATUS_REQUIRED);
				status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, CommonMessage.DATA_REQUIRED);
				return new ResponseMessage<>(status, null);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}
	public List<Project> getProjects() {
//		ResponseStatus status = null;
		
			
			return projectRepository.findAll() ;
//			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, CommonMessage.SUCCESS);
//			return new ResponseMessage<>(status, projectList);
//		
	}
	

}
