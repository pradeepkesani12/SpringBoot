package com.optisol.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.optisol.domain.Project;
import com.optisol.helper.ProjectServiceHelper;
import com.optisol.messages.ResponseMessage;


@RestController
@Service
public class ProjectController {
	
	@Autowired
	private ProjectServiceHelper projectServiceHelper;

	@PostMapping ("/project")
	public ResponseMessage<Project> createProject(@RequestBody Project obj, HttpServletRequest request, HttpServletResponse response) throws IOException{
			return projectServiceHelper.createProject(obj, response);
    
	}
	@GetMapping("/getprojects")
	public List<Project> getProject( HttpServletRequest request, HttpServletResponse response) throws IOException{
			return projectServiceHelper.getProjects();
	}
	
	
}
