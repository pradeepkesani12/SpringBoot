package com.optisol.service;

import java.sql.Date;
import java.util.List;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.optisol.domain.Metrics;
import com.optisol.repository.MetricsRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MetricService {
	@Autowired
	private Metrics Repository;
	Logger log=(Logger) LoggerFactory.logger(MatricsService.class);
	//scduled a project data add in db (every 1sec)
	@Scheduled(fixedRate = 1000)
	public void addproject2DB()
	{
		Metrics metrics=new Metrics();
		metrics.setBugs(1);
		metrics.setCodeSmells(0);
		Repository.save(metrics);
	System.out.println("add service call in "+new Date(0).toString());
	}
	@Scheduled(cron = "0 0/1 * * * ?")
	public void fetchDB()
	{
		List<Metrics> metrics =Repository.findAll();
		System.out.println("fetch service call in"+new Date(0).toString());
		System.out.println("no of record fatched:"+metrics.size());
		log.info("metrics: {})",metrics);
		
	}
}
