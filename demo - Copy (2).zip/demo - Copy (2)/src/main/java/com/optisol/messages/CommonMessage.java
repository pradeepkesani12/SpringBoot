package com.optisol.messages;

public class CommonMessage {
	private CommonMessage() {}
	public static final String SUCCESS = "Success";

	
	public static final String PROCESS_FAILED = "process.Failed";
	public static final String DATA_REQUIRED = "user.DataRequired";
	public static final String TEAMDOMAIN_NOTEXIST = "teamDomain.NotExist";
	public static final String TEAM_NOTEXIST = "team.notExists";
	public static final String NORECORD = "user.NoRecord";
	public static final String INVALIDUSER = "Invalid User";
	public static final String INTERNALERROR = "InternalError";
	public static final String COMPANY_NOTEXIST = "company.notExists";
	public static final String COMPANY_ALREADYEXISTS = "company.AlreadyExists";
	public static final String TEAMDOMAIN_DELETED = "teamDomain.Deleted";
	public static final String TEAMDOMAIN_EXISTS = "teamDomain.AlreadyExist";
	public static final String RESEND_EDIT_SUCCESS = "resendEdit.Success";
	public static final String INVITEUSER = "user.InviteSuccess";
	
	
	public static final String OWNERSHIP_NOTEXIST = "Ownership Transfer Request Not Exist";
	public static final String UNAUTHORIZED_USER = "Unauthorized User";
	public static final String NOTDELETE_LAST_PROJECT="Not able to delete Last Project ";	
	public static final String NOTDELETE_PROJECT_MANAGER="Not able to delete Project Manager";
	public static final String PROJECT_LIMIT_REACHED = "Pixly Basic is free to use with up to 100 photos and 3 projects. Upgrade to Pixly Pro to access unlimited photos and projects.";

}
