package com.optisol.messages;

public class ResponseStatusCode {
	
	private ResponseStatusCode() {
	    throw new IllegalStateException("ResponseStatusCode class");
	}
	
	public static final int STATUS_OK 				= 200;
	public static final int STATUS_CREATED          = 201;
	
	public static final int STATUS_UNAUTHORIZED 	= 401;
	public static final int STATUS_INVALID 	= 400;
	public static final int STATUS_CONFLICT 		= 409;
	public static final int STATUS_INTERNAL_ERROR 	= 500;
	public static final int STATUS_REQUIRED 		= 230;
	public static final int STATUS_NOTMATCHED 		= 229;
	public static final int STATUS_NORECORD 		= 204;
	public static final int STATUS_OTP_EXPIRED		= 227;
	public static final int STATUS_OTP_ATTEMPT_EXCEEDED		= 228;
	public static final int STATUS_ALREADY_EXISTS	= 302;	
	public static final int STATUS_PULLFAIL		= 231;
	public static final int STATUS_NOTDELETE_LASTPROJECT = 232;
	public static final int EXCESSAMOUNT		= 233;
	public static final int SOURCEAMOUNTLOW    = 234;
	public static final int TRANSACTEDCARD    = 235;
	public static final int INACTIVEUSER    = 236;
	public static final int REVIEWTRANSACTIONSCORE    = 237;
	public static final int NOTVERIFIED    = 238;
	public static final int PARTIALREGISTER    = 239;
	public static final int STATUS_DELETED    = 240;
	public static final int STATUS_API_EXCEEDED		= 241;
	public static final int STATUS_NOTDELETE_MANAGER	= 242;
	
	public static final int STATUS_MISMATCH		= 243;
	public static final int STATUS_SAME	= 244;
	public static final int STATUS_WRONG	= 245;
	public static final int STATUS_PROJECT_NOTEXIST	= 246;
	
	public static final int STATUS_ACCESS_DENIED		= 401;
	public static final int STATUS_INVALID_PHONENUMBER		= 402;
	
	public static final int STATUS_BAD_GATEWAY		= 502;
	public static final int STATUS_FORBIDDEN	= 403;

}
