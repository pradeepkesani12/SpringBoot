package com.optisol.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.optisol.domain.Metrics;
import com.optisol.domain.Project;

public interface MetricsRepository extends JpaRepository<Metrics, Long>{

	Metrics save(Metrics metric);

}
