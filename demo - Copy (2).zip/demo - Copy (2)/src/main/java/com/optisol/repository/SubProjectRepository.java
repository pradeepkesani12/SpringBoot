package com.optisol.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.optisol.domain.Project;
import com.optisol.domain.SubProject;

public interface SubProjectRepository extends JpaRepository<SubProject, Long>{ 

}
