package com.optisol.scheduler;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.Cookie;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class DailyRoutine {
	
	@Autowired
	private RestTemplate restTemplate;

	@Scheduled(cron = "0 0/1 * * * ?")
	public void daily() {
		System.out.println("schedular called "+ new Date());
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		ResponseEntity entity = restTemplate.exchange("https://sonarqube.optisolbusiness.com/api/authentication/login?"
				+ "login=javateam&password=javateam", HttpMethod.POST, new HttpEntity<>(headers),
				ResponseEntity.class);

		

		String url = "https://sonarqube.optisolbusiness.com/api/measures/search?"
				+ "projectKeys=Pixly-Notification-test&metricKeys=vulnerabilities,bugs,code_smells";
		

		List<String> tokenList = entity.getHeaders().get("Set-Cookie");
System.out.println(tokenList);
System.out.println(tokenList.get(0));
System.out.println(tokenList.get(1));
String[] xsrf = tokenList.get(0).split(";");
String[] jwt = tokenList.get(1).split(";");

System.out.println(xsrf[0]);
  System.out.println(jwt[0]);

String token = jwt[0] + "; " +xsrf[0];
headers.set("Cookie", token);

		System.out.println(restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(headers),
				String.class));
		

		
		
			
			
			
		
			
			
//System.out.println(restTemplate.exchange("https://sonarqube.optisolbusiness.com/api/authentication/login?"
//				+ "login=javateam&password=javateam", HttpMethod.POST, new HttpEntity<>(headers),
//				String.class));

//		ResponseEntity<JSONObject> projecResponse = restTemplate.exchange("https://sonarqube.optisolbusiness.com/api/authentication/login?"
//				+ "login=javateam&password=javateam", HttpMethod.POST, new HttpEntity<>(headers),
//				JSONObject.class);
//		System.out.println(projecResponse);
	}
}
