package com.optisol.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="metrics")
public class Metrics {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="id" , nullable = false ,unique = true)
	private long id;
	
	@Column(name = "code_smells")
	private long codeSmells;
	
	@Column(name = "bugs")
	private long bugs;
	
	@Column(name = "vulnerabilities")
	private long vulnerabilities;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getCodeSmells() {
		return codeSmells;
	}

	public void setCodeSmells(long codeSmells) {
		this.codeSmells = codeSmells;
	}

	public long getBugs() {
		return bugs;
	}

	public void setBugs(long bugs) {
		this.bugs = bugs;
	}

	public long getVulnerabilities() {
		return vulnerabilities;
	}

	public void setVulnerabilities(long vulnerabilities) {
		this.vulnerabilities = vulnerabilities;
	}

	public void save(Metrics metrics) {
		// TODO Auto-generated method stub
		
	}

	public List<Metrics> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
