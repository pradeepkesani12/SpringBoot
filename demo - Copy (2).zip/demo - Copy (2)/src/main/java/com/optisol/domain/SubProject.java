package com.optisol.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="sub_project")
public class SubProject {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="id" , nullable = false ,unique = true)
	private long id;
	
	@Column(name="sonar_name")
	private String sonarName;
	
	@Column(name = "code_smells")
	private long codeSmells;
	
	@Column(name = "bugs")
	private long bugs;
	
	@Column(name = "vulnerabilities")
	private long vulnerabilities;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSonarName() {
		return sonarName;
	}

	public void setSonarName(String sonarName) {
		this.sonarName = sonarName;
	}

	public long getCodeSmells() {
		return codeSmells;
	}

	public void setCodeSmells(long codeSmells) {
		this.codeSmells = codeSmells;
	}

	public long getBugs() {
		return bugs;
	}

	public void setBugs(long bugs) {
		this.bugs = bugs;
	}

	public long getVulnerabilities() {
		return vulnerabilities;
	}

	public void setVulnerabilities(long vulnerabilities) {
		this.vulnerabilities = vulnerabilities;
	}
	
}
